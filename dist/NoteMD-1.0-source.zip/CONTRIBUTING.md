# Contributing to NoteMD

Obrigado pelo interesse em contribuir.

## Desenvolvimento

Requisitos:

- macOS 14 ou superior;
- Xcode 16 ou superior;
- Swift 6.

Clone o repositório, abra `Package.swift` no Xcode e execute o produto
**NoteMD**. Antes de abrir um pull request:

```sh
swift build
```

Mantenha cada alteração focada, descreva o comportamento testado e inclua
capturas de ecrã quando modificar a interface.

## Reportar problemas

Inclua a versão do macOS, passos para reproduzir, resultado esperado e
relatórios de crash relevantes. Não publique notas pessoais ou caminhos com
informação privada.
