# NoteMD

<img src="Assets/NoteMD-AppIcon-1024.png" alt="Ícone do NoteMD" width="160">

Editor Markdown nativo para macOS, construído com SwiftUI e AppKit. Organiza
notas em notebooks portáteis, guardados como ficheiros Markdown numa pasta
escolhida pelo utilizador.

## Funcionalidades

- notebooks expansíveis e personalizáveis por cor;
- notas em abas, com indicação de alterações por guardar;
- editor Markdown com toolbar, atalhos e realce de sintaxe;
- editor visual por blocos e modo dividido;
- tabelas, checklists, listas, citações, código, links e imagens;
- imagens locais guardadas na pasta `assets` de cada nota;
- exportação para PDF;
- interface em Português, Inglês e Francês;
- leitura e gravação numa estrutura de ficheiros aberta;
- confirmação ao fechar notas com alterações.

## Estrutura dos dados

```text
Pasta das notas/
└── Nome do notebook/
    └── Nome da nota/
        ├── note.md
        ├── .note.json
        └── assets/
            └── image.png
```

Os ficheiros `note.md` permanecem acessíveis a outros editores.

## Requisitos

- macOS 14 ou superior;
- Xcode 16 ou superior;
- Swift 6.

## Executar

Abra `Package.swift` no Xcode, selecione o produto **NoteMD** e use `⌘R`.

Pelo terminal:

```sh
swift run NoteMD
```

Para validar a compilação:

```sh
swift build
```

## Downloads

As versões compiladas para macOS são disponibilizadas na área **Releases** do
GitHub como arquivo ZIP e instalador PKG.

Os artefactos atuais são assinados localmente de forma ad-hoc. Uma distribuição
pública sem avisos do Gatekeeper requer certificado Apple Developer e
notarização.

## Privacidade

As notas são guardadas localmente na pasta escolhida. NoteMD não possui
serviço de conta nem envia o conteúdo das notas para um servidor.

## Contribuir

Consulte [CONTRIBUTING.md](CONTRIBUTING.md).

## Licença

Ainda não foi selecionada uma licença para o projeto.
